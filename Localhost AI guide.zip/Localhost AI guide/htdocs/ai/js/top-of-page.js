document.write(
'<img src="/ai/images/Logo_eCraft2Learn.png" alt="" width="215" height="41" />' +
'<h2 class="student-guide">A student guide to building AI apps and artefacts</h2>' +
'<h2 class="teacher-guide">A teacher&apos;s guide to building AI apps and artefacts</h2>');
document.close();