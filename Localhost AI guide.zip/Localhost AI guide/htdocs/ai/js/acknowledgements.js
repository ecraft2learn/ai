document.write(
'<h3>Acknowledgements</h3>' +
'<p>This research was supported by the <a href="https://project.ecraft2learn.eu/" target="_blank">eCraft2Learn project</a> ' +
"funded by the European Union's Horizon 2020 Coordination & Research and Innovation Action " +
'under Grant Agreement No 731345.</p> ' +
'<img src="/ai/images/eCraft2Learn-Final0.1.png" alt="eCraft2Learn icon">');
document.close();