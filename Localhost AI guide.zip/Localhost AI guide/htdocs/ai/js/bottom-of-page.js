document.write(
'<p>&nbsp;</p>' +
'<p><img src="/ai/images/Logo_EU_white.png" alt="" width="330" height="66" />&nbsp; &nbsp;<img src="/ai/images/Logo_PD.png?raw=true" alt="" width="60" height="60" />&nbsp; &nbsp;</p>');
document.close();