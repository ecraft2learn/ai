/** @interface */
function IDE_Morph(){};
IDE_Morph.prototype.init = function () {};

function WorldMorph(){};


